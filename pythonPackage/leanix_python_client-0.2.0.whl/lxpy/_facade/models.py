"""Data types used in lxpy."""

from collections import namedtuple

# Basic API client configuration based on APP instance and API token
ClientConfiguration = namedtuple(
    'ClientConfiguration',
    'base_url api_token'
)

# Basic workspace class
Workspace = namedtuple(
    'Workspace',
    'id name instance_url'
)
