# -*- coding: utf-8 -*-
"""Custom exceptions."""


class LxPyException(Exception):
    """Custom exception."""

    pass
