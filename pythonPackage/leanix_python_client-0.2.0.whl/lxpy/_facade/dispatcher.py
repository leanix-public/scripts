# -*- coding: utf-8 -*-
"""Dispatch generic API functions from specialized to base client."""


class Dispatcher():
    """Dispatch generic API functions from specialized to base client."""

    def get_workspace_from_access_token(self):
        """Extract workspace binding from access token."""
        return self.base_client.get_workspace_from_access_token()

    def get(self, api_path):
        """Run a get request against REST API."""
        return self.base_client.get(api_path, self)

    def put(self, api_path, body):
        """Run a put request against REST API."""
        return self.base_client.put(api_path, body, self)

    def post(self, api_path, body):
        """Run a put request against REST API."""
        return self.base_client.post(api_path, body, self)

    def delete(self, api_path):
        """Run a put request against REST API."""
        return self.base_client.delete(api_path, self)

    def start_job(self, api_path, body):
        """Get the current status of a previously started background job."""
        return self.base_client.start_job(api_path, body, self)

    def get_job_status(self, job_id):
        """Get the current status of a previously started background job."""
        return self.base_client.get_job_status(job_id, self)

    def wait_for_job(self, job_id):
        """Wait for a previously started background job."""
        return self.base_client.wait_for_job(job_id, self)

    def get_token_expiry(self):
        """Return the epoch timestamp when the access token expires."""
        return self.base_client.get_token_expiry()
