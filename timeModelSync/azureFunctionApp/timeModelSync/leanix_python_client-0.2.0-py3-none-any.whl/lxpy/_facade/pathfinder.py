# -*- coding: utf-8 -*-
"""LeanIX Pathfinder API handler."""

from lxpy import pathfinder_api
from lxpy._facade.base_client import BaseClient, assert_success_of_response
from lxpy._facade.dispatcher import Dispatcher


class Pathfinder(Dispatcher):
    """LeanIX Pathfinder API handler."""

    def __init__(self, config):
        """Construct with client configuration."""
        self.base_client = BaseClient(config)

    def get_api_handler(self):
        """Return the internal API handler."""
        return pathfinder_api

    def get_api_base_url(self):
        """Return the internal base URL for this service."""
        return ('https://{}/services/pathfinder/v1'
                .format(self.base_client.config.base_url))

    ##########################################################################
    # PUBLIC ENDPOINTS
    ##########################################################################

    def factsheets(self):
        """Connect to Pathfinder's factSheets API.

        https://app.leanix.net/services/pathfinder/v1/docs/#/factSheets

        :return: pathfinder_api.FactSheetsApi
        """
        return pathfinder_api.FactSheetsApi(
            self.base_client.bind_and_refresh(self))

    def graphql(self):
        """Connect to Pathfinder's graphql API.

        https://app.leanix.net/services/pathfinder/v1/docs/#/graphql

        :return: pathfinder_api.GraphqlApi
        """
        return pathfinder_api.GraphqlApi(
            self.base_client.bind_and_refresh(self))

    ##########################################################################
    # API CLIENT'S SPECIAL CAPABILITIES
    ##########################################################################

    def graphql_all_fact_sheets(self, node_configuration, page_callback,
                                page_size=40, stop_after_first_page=False):
        """Run a paged allFactSheets query."""
        gql = self.graphql()
        request = pathfinder_api.models.GraphQLRequest()

        after = ''
        total_retrieved = 0

        while True:
            request.query = """
            {
                allFactSheets(first:""" + str(page_size) + after + """)
                {
                    pageInfo {
                        hasNextPage
                        endCursor
                    }
                    edges
                    {
                        node
                        """ + node_configuration + """
                    }
                }
            }
            """

            api_response = gql.process_graph_ql(request)
            assert_success_of_response(api_response)
            fact_sheets = self.__get_nodes(api_response, 'allFactSheets')
            page_callback(fact_sheets)
            total_retrieved += len(fact_sheets)
            page_info = self.__get_page_info(api_response, 'allFactSheets')
            after = ', after:"' + page_info['endCursor'] + '"'
            if not page_info['hasNextPage'] or stop_after_first_page:
                break

        return total_retrieved

    def get_workspace_settings(self):
        """Return the current workspace settings."""
        _, response = self.get('/settings')
        return response['data']

    def update_workspace_settings(self, settings):
        """Update the current workspace settings with the given values."""
        code, api_response = self.put('/settings', settings)
        assert_success_of_response(code, api_response)

    ##########################################################################
    # PRIVATE FUNCTIONS
    ##########################################################################

    def __get_nodes(self, response, query):
        """Convert GQL response with node-edges to flat list of edges."""
        return [
            fs_node['node']
            for fs_node in response.data[query]['edges']
        ]

    def __get_page_info(self, response, query):
        """Return the pageInfo section from the GQL response."""
        return response.data[query]['pageInfo']
