# -*- coding: utf-8 -*-
"""LeanIX Metrics API handler."""

from lxpy import metrics_api
from lxpy._facade.base_client import BaseClient
from lxpy._facade.dispatcher import Dispatcher


class Metrics(Dispatcher):
    """LeanIX Metrics API handler."""

    def __init__(self, config):
        """Construct with client configuration."""
        self.base_client = BaseClient(config)

    def get_api_handler(self):
        """Return the internal API handler."""
        return metrics_api

    def get_api_base_url(self):
        """Return the internal base URL for this service."""
        return ('https://{}/services/metrics/v1'
                .format(self.base_client.config.base_url))

    ##########################################################################
    # PUBLIC ENDPOINTS
    ##########################################################################

    def points(self):
        """Connect to Metrics's Points API.

        https://svc.leanix.net/services/metrics/v1/docs/#/points

        :return: metrics_api.PointsApi
        """
        return metrics_api.PointsApi(
            self.base_client.bind_and_refresh(self))

    def measurements(self):
        """Connect to Metrics's measurements API.

        https://svc.leanix.net/services/metrics/v1/docs/#/measurements

        :return: metrics_api.MeasurementsApi
        """
        return metrics_api.MeasurementsApi(
            self.base_client.bind_and_refresh(self))

    def series(self):
        """Connect to Metrics's series API.

        https://svc.leanix.net/services/metrics/v1/docs/#/series

        :return: metrics_api.SeriesApi
        """
        return metrics_api.SeriesApi(
            self.base_client.bind_and_refresh(self))
