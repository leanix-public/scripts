# -*- coding: utf-8 -*-
"""LeanIX MTM API handler."""

from lxpy import mtm_api
from lxpy._facade.base_client import BaseClient
from lxpy._facade.dispatcher import Dispatcher


class Mtm(Dispatcher):
    """LeanIX MTM API handler."""

    def __init__(self, config):
        """Construct with client configuration."""
        self.base_client = BaseClient(config)

    def get_api_handler(self):
        """Return the internal API handler."""
        return mtm_api

    def get_api_base_url(self):
        """Return the internal base URL for this service."""
        return ('https://{}/services/mtm/v1'
                .format(self.base_client.config.base_url))

    ##########################################################################
    # PUBLIC ENDPOINTS
    ##########################################################################

    def workspaces(self):
        """Connect to MTM's workspaces API.

        https://app.leanix.net/services/mtm/v1/docs/#/workspaces

        :return: mtm_api.WorkspacesApi
        """
        return mtm_api.WorkspacesApi(self.base_client.bind_and_refresh(self))
