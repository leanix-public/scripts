# -*- coding: utf-8 -*-
"""LeanIX Webhooks API handler."""

from lxpy import webhooks_api
from lxpy._facade.base_client import BaseClient
from lxpy._facade.dispatcher import Dispatcher


class Webhooks(Dispatcher):
    """LeanIX Webhooks API handler."""

    def __init__(self, config):
        """Construct with client configuration."""
        self.base_client = BaseClient(config)

    def get_api_handler(self):
        """Return the internal API handler."""
        return webhooks_api

    def get_api_base_url(self):
        """Return the internal base URL for this service."""
        return ('https://{}/services/webhooks/v1'
                .format(self.base_client.config.base_url))

    ##########################################################################
    # PUBLIC ENDPOINTS
    ##########################################################################

    def subscriptions(self):
        """Connect to Webhook's subscriptions API.

        https://app.leanix.net/services/webhooks/v1/docs/#/subscriptions

        :return: webhooks_api.SubscriptionsApi
        """
        return webhooks_api.SubscriptionsApi(
            self.base_client.bind_and_refresh(self))
