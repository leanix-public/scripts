# -*- coding: utf-8 -*-
"""Reading and updating API configurations."""

import json
from os import environ
from os.path import isfile

from lxpy._facade.exceptions import LxPyException
from lxpy._facade.models import ClientConfiguration


class ConfigHandler():
    """Simplify reading and updating API client configurations."""

    __API_CONFIGURATION_FILE_ENV__ = 'LEANIX_API_CLIENT_CONFIG'

    def __init__(self, config_file=None):
        """Construct and load configuration."""
        if config_file:
            self.__API_CONFIGURATION_FILE__ = config_file
        else:
            self.__API_CONFIGURATION_FILE__ = environ.get(
                self.__API_CONFIGURATION_FILE_ENV__, None)
        if not self.__API_CONFIGURATION_FILE__:
            raise LxPyException('ERROR: Env variable {}'.format(
                self.__API_CONFIGURATION_FILE_ENV__)
                + ' pointing to a configuration json-file was not set: '
                + str(self.__API_CONFIGURATION_FILE__))
        self.config = self.__load_config()

    def create_or_update_label(self, label, base_url, api_token):
        """Create or update configuration for given label."""
        self.config[label] = {
            'base_url': base_url,
            'api_token': api_token,
        }
        self.__save_config()

    def delete_label(self, label):
        """Delete a label from configuration."""
        del self.config[label]
        self.__save_config()

    def has_label(self, label):
        """Check if configuration contains provided label."""
        return self.config.get(label, None)

    def get_labels(self):
        """Return all available labels."""
        return self.config

    def print_config(self):
        """Print configuration to stdout."""
        print(json.dumps(self.config, indent=4))

    def get_config_for_label_or_exit(self, label):
        """Print configuration for given label or call to exit 1."""
        config = self.config.get(label, None)
        if not config:
            print('No API configuration found for label "{}"'
                  .format(label))
            exit(1)
        return ClientConfiguration(
            base_url=config['base_url'],
            api_token=config['api_token']
        )

    def __load_config(self):
        if not isfile(self.__API_CONFIGURATION_FILE__):
            with open(self.__API_CONFIGURATION_FILE__, 'w+') as conf:
                conf.write(json.dumps({}, indent=4) + '\n')
        config = json.load(open(self.__API_CONFIGURATION_FILE__))
        self.__migrate_config(config)
        return config

    def __save_config(self):
        with open(self.__API_CONFIGURATION_FILE__, 'w+') as conf:
            conf.write(json.dumps(self.config, indent=4) + '\n')

    def __migrate_config(self, config):
        """Run migrations if format was changed."""
        for key in config.keys():
            sub_config = config[key]
            # Delete svc-instance if present (not used anymore)
            try:
                del sub_config['svc-instance']
            except KeyError:
                pass  # Was not present
            # Map old property names
            self.__copy_from_to_and_delete_key(
                sub_config, 'app-instance', 'base_url')
            self.__copy_from_to_and_delete_key(
                sub_config, 'api-token', 'api_token')

    def __copy_from_to_and_delete_key(self, sub_config, from_key, to_key):
        if not sub_config.get(from_key, None):
            return  # Nothing to do
        sub_config[to_key] = sub_config[from_key]
        del sub_config[from_key]
