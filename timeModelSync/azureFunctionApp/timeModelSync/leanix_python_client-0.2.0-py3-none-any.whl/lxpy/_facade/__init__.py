"""Facade for the internal swagger bindings."""
