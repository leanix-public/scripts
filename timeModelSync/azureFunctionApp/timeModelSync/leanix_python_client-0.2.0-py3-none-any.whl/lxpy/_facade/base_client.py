# -*- coding: utf-8 -*-
"""LeanIX Base API handler."""

from base64 import b64decode
from datetime import datetime
from json import dumps, loads
from time import sleep

from lxpy._facade.exceptions import LxPyException
from lxpy._facade.models import ClientConfiguration, Workspace

from requests import delete as delete_request
from requests import get as get_request
from requests import post as post_request
from requests import put as put_request


class BaseClient(object):
    """LeanIX Base API handler.

    This class is not intended to be instantiated directly.
    """

    def __init__(self, config):
        """Construct with provided configuration and get an access token."""
        if not isinstance(config, ClientConfiguration):
            raise LxPyException('Invalid configuration provided.')
        if not config.base_url:
            raise LxPyException('base_url not set for configuration.')
        if not config.api_token:
            raise LxPyException('api_token not set for configuration.')
        self.config = config
        self.__authenticate()

    def get_workspace_from_access_token(self):
        """Extract workspace binding from access token."""
        ac_decoded = self.__decode_access_token_payload(
            self.access_token)
        ac_json = loads(ac_decoded)
        ws_id = self.__get_from_json_or_default(
            ac_json, 'principal.permission.workspaceId', None)
        ws_name = self.__get_from_json_or_default(
            ac_json, 'principal.permission.workspaceName', None)
        ws_instance_url = self.__get_from_json_or_default(
            ac_json, 'instanceUrl', None)
        return Workspace(
            id=ws_id,
            name=ws_name,
            instance_url=ws_instance_url
        )

    def get(self, api_path, client):
        """Run a get request against REST API."""
        self.__refresh_token_if_necessary()
        src_url = client.get_api_base_url() + api_path
        headers = {
            'Authorization': 'Bearer ' + self.access_token
        }
        return self.__process_response(
            get_request(src_url, headers=headers))

    def post(self, api_path, body, client):
        """Run a post request against REST API."""
        self.__refresh_token_if_necessary()
        src_url = client.get_api_base_url() + api_path
        headers = {
            'Authorization': 'Bearer ' + self.access_token
        }
        return self.__process_response(
            post_request(src_url, headers=headers, json=body))

    def put(self, api_path, body, client):
        """Run a put request against REST API."""
        self.__refresh_token_if_necessary()
        src_url = client.get_api_base_url() + api_path
        headers = {
            'Authorization': 'Bearer ' + self.access_token
        }
        return self.__process_response(
            put_request(src_url, headers=headers, json=body))

    def delete(self, api_path, client):
        """Run a delete request against REST API."""
        self.__refresh_token_if_necessary()
        src_url = client.get_api_base_url() + api_path
        headers = {
            'Authorization': 'Bearer ' + self.access_token
        }
        return self.__process_response(
            delete_request(src_url, headers=headers))

    def get_token_expiry(self):
        """Return the epoch timestamp when the access token expires."""
        access_token = self.__decode_access_token_payload(
            self.access_token)
        return loads(access_token)['exp']

    def start_job(self, api_path, body, client):
        """Start a background job via the public API."""
        code, api_response = client.post(api_path, body)
        assert_success_of_response(api_response, code)
        job_id = api_response['data']['jobId']
        print('Job started with id "{}"'.format(job_id))
        return job_id

    def get_job_status(self, job_id, client):
        """Get the current status of a previously started background job."""
        _, response = client.get('/jobs/{}/status'.format(job_id))
        try:
            response = loads(response)
        except TypeError:
            pass  # Already JSON
        return (
            response['data']['status'] if response.get('data', None) else None,
            response
        )

    def wait_for_job(self, job_id, client):
        """Wait for a previously started background job."""
        print('Waiting for job with id "{}" '.format(job_id), end='')
        while True:
            print('.', end='')
            sleep(0.5)
            status, response = self.get_job_status(job_id, client)
            if status in [
                    'DONE', 'CANCELED', 'DONE_WITHERRORS', 'ERROR']:
                print()
                return status

    def bind_and_refresh(self, client):
        """Initialize an API connection using swagger-bindings.

        This function also checks if the token is expired and refreshes
        it if necessary.
        """
        self.__refresh_token_if_necessary()
        configuration = client.get_api_handler().Configuration()
        configuration.host = client.get_api_base_url()
        configuration.access_token = self.access_token
        return client.get_api_handler().ApiClient(configuration)

    def __process_response(self, response):
        if response.status_code == 200:
            return response.status_code, loads(response.text)
        else:
            return response.status_code, response.text

    def __refresh_token_if_necessary(self):
        expiry_epoch = self.get_token_expiry()
        now = int(datetime.now().timestamp())
        expired = expiry_epoch - 5 - now <= 0  # w/ 5 seconds headroom
        if not expired:
            return
        self.__authenticate()

    def __authenticate(self):
        token_url = 'https://{}/services/mtm/v1/oauth2/token/'.format(
            self.config.base_url)
        try:
            r = post_request(token_url,
                             data={'grant_type': 'client_credentials'},
                             auth=('apitoken', self.config.api_token)
                             )
        except Exception as e:
            raise LxPyException('Could not get access token.', e)
        if r.status_code != 200:
            raise LxPyException(
                'Could not get access token. HTTP', r.status_code)
        self.access_token = loads(r.text)['access_token']

    def __decode_access_token_payload(self, access_token):
        """Decode JWT access token to JSON.

        Visit https://jwt.io/introduction/ for detailed documentation.
        """
        ac_split = access_token.split('.')
        jwt_payload = dumps(loads(b64decode(ac_split[1] + '===')), indent=4)
        return jwt_payload

    def __get_from_json_or_default(self, json, path, default_value):
        """Load a key breadcrumb from a JSON object or return default."""
        if not path:
            return default_value
        json = json if json else {}
        try:
            for breadcrumb in path.split('.'):
                json = json[breadcrumb]
            return json if json else default_value
        except KeyError:
            return default_value


def assert_success_of_response(response, code=200):
    """Raise an LxPyException if the API response contained errors."""
    if code >= 300:
        raise LxPyException('Request failed with status code {}'.format(code))
    try:
        if response.errors and len(response.errors) > 0:
            raise LxPyException(response.errors)
    except AttributeError:
        pass  # Does not have an error field
